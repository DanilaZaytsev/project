QUnit.module( "Double", function() {
	QUnit.test( "has a test", function( assert ) {
		assert.ok( true );
	} );

	QUnit.test( "has another test", function( assert ) {
		assert.ok( true );
	} );
} );
